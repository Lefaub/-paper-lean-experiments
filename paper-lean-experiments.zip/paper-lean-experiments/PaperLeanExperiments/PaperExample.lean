import PaperLeanExperiments.Reconstruction
import PaperLeanExperiments.Spectrum

namespace PaperLean

/-- The paper box has the exact three symmetric invariants used by reconstruction. -/
theorem paperBox_invariants :
    paperBox.edgeSum = (24 : ℝ) / 5 ∧
    paperBox.pairSum = (29 : ℝ) / 4 ∧
    paperBox.volume = (69 : ℝ) / 20 := by
  constructor
  · exact paperBox_edgeSum
  constructor
  · exact paperBox_pairSum
  · exact paperBox_volume

/-- Concrete reconstruction cubic for the paper's working example. -/
theorem paperBox_cubic (x : ℝ) :
    (x - 1) * (x - (3 : ℝ) / 2) * (x - (23 : ℝ) / 10) =
      x^3 - ((24 : ℝ) / 5) * x^2 + ((29 : ℝ) / 4) * x - (69 : ℝ) / 20 := by
  ring

end PaperLean
