import Mathlib

namespace PaperLean

/-- A rectangular box with side lengths `a`, `b`, and `c`. -/
structure Box where
  a : ℝ
  b : ℝ
  c : ℝ
  deriving Repr

namespace Box

/-- Volume of a rectangular box. -/
def volume (B : Box) : ℝ := B.a * B.b * B.c

/-- Surface area of a rectangular box. -/
def surfaceArea (B : Box) : ℝ := 2 * (B.a * B.b + B.a * B.c + B.b * B.c)

/-- Sum of the three side lengths. This is the symmetric degree-one invariant. -/
def edgeSum (B : Box) : ℝ := B.a + B.b + B.c

/-- The degree-two elementary symmetric polynomial in the side lengths. -/
def pairSum (B : Box) : ℝ := B.a * B.b + B.a * B.c + B.b * B.c

/-- Uniformly scale a box by `s`. -/
def scale (s : ℝ) (B : Box) : Box :=
  ⟨s * B.a, s * B.b, s * B.c⟩

end Box

/-- Working example used in the paper: `(a,b,c) = (1, 1.5, 2.3)`. -/
def paperBox : Box :=
  ⟨1, (3 : ℝ) / 2, (23 : ℝ) / 10⟩

@[simp] theorem paperBox_volume : paperBox.volume = (69 : ℝ) / 20 := by
  norm_num [paperBox, Box.volume]

@[simp] theorem paperBox_surfaceArea : paperBox.surfaceArea = (29 : ℝ) / 2 := by
  norm_num [paperBox, Box.surfaceArea]

@[simp] theorem paperBox_edgeSum : paperBox.edgeSum = (24 : ℝ) / 5 := by
  norm_num [paperBox, Box.edgeSum]

@[simp] theorem paperBox_pairSum : paperBox.pairSum = (29 : ℝ) / 4 := by
  norm_num [paperBox, Box.pairSum]

end PaperLean
