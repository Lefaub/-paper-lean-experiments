import PaperLeanExperiments.Weyl

namespace PaperLean

/--
The side lengths are the roots of the monic cubic determined by the three
symmetric geometric invariants.
-/
theorem cubic_identity (B : Box) (x : ℝ) :
    (x - B.a) * (x - B.b) * (x - B.c) =
      x^3 - B.edgeSum * x^2 + B.pairSum * x - B.volume := by
  simp [Box.edgeSum, Box.pairSum, Box.volume]
  ring

/-- Surface area is twice the degree-two elementary symmetric invariant. -/
theorem pairSum_from_surfaceArea (B : Box) :
    B.surfaceArea / 2 = B.pairSum := by
  simp [Box.surfaceArea, Box.pairSum]
  ring

/--
A direct formal bridge from the Weyl coefficients to the reconstruction cubic.
This is the algebraic core of the box reconstruction used in the paper.
-/
theorem cubic_from_weyl (B : Box) (x : ℝ) :
    (x - B.a) * (x - B.b) * (x - B.c) =
      x^3
        - (4 * Real.pi * weylA2 B) * x^2
        + ((-16 * Real.pi * weylA1 B) / 2) * x
        - (6 * Real.pi^2 * weylA0 B) := by
  rw [recover_edgeSum, recover_surfaceArea, recover_volume]
  simp [Box.edgeSum, Box.surfaceArea, Box.volume]
  ring

end PaperLean
