import PaperLeanExperiments.Geometry

namespace PaperLean

/--
The dimensionless part of the Dirichlet eigenvalue for a rectangular box.
The paper's eigenvalue is `π² * normalizedEigenvalue B l n m`.
Indices are represented by `ℕ`; paper-relevant modes use positive indices.
-/
def normalizedEigenvalue (B : Box) (l n m : ℕ) : ℝ :=
  ((l : ℝ) / B.a)^2 + ((n : ℝ) / B.b)^2 + ((m : ℝ) / B.c)^2

/-- Exact separated Dirichlet eigenvalue formula for the rectangular box. -/
def eigenvalue (B : Box) (l n m : ℕ) : ℝ :=
  Real.pi^2 * normalizedEigenvalue B l n m

/-- Every normalized mode expression is nonnegative. -/
theorem normalizedEigenvalue_nonneg (B : Box) (l n m : ℕ) :
    0 ≤ normalizedEigenvalue B l n m := by
  unfold normalizedEigenvalue
  positivity

/-- Every exact box eigenvalue is nonnegative. -/
theorem eigenvalue_nonneg (B : Box) (l n m : ℕ) :
    0 ≤ eigenvalue B l n m := by
  unfold eigenvalue
  exact mul_nonneg (sq_nonneg Real.pi) (normalizedEigenvalue_nonneg B l n m)

/-- Exchanging two axes and the corresponding mode indices leaves the spectrum unchanged. -/
theorem normalizedEigenvalue_swap_ab
    (a b c : ℝ) (l n m : ℕ) :
    normalizedEigenvalue ⟨a, b, c⟩ l n m =
      normalizedEigenvalue ⟨b, a, c⟩ n l m := by
  simp [normalizedEigenvalue]
  ring

/-- Exact normalized value of the first `(1,1,1)` mode for the paper's box. -/
@[simp] theorem paperBox_first_normalized :
    normalizedEigenvalue paperBox 1 1 1 = (7777 : ℝ) / 4761 := by
  norm_num [normalizedEigenvalue, paperBox]

/-- Exact symbolic first eigenvalue of the paper's box. -/
theorem paperBox_first_eigenvalue :
    eigenvalue paperBox 1 1 1 = Real.pi^2 * ((7777 : ℝ) / 4761) := by
  rw [eigenvalue, paperBox_first_normalized]

end PaperLean
