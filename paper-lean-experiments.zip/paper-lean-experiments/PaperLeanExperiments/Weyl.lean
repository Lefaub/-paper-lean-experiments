import PaperLeanExperiments.Geometry

namespace PaperLean

/-- Leading Weyl coefficient for the counting function in dimension three. -/
def weylA0 (B : Box) : ℝ := B.volume / (6 * Real.pi^2)

/-- Boundary Weyl coefficient for a Dirichlet rectangular box. -/
def weylA1 (B : Box) : ℝ := -B.surfaceArea / (16 * Real.pi)

/-- Third box Weyl coefficient, expressed through the sum of side lengths. -/
def weylA2 (B : Box) : ℝ := B.edgeSum / (4 * Real.pi)

/-- Recover the volume exactly from `A₀`. -/
theorem recover_volume (B : Box) :
    6 * Real.pi^2 * weylA0 B = B.volume := by
  unfold weylA0
  field_simp [ne_of_gt Real.pi_pos]

/-- Recover the surface area exactly from `A₁`. -/
theorem recover_surfaceArea (B : Box) :
    -16 * Real.pi * weylA1 B = B.surfaceArea := by
  unfold weylA1
  field_simp [ne_of_gt Real.pi_pos]
  ring

/-- Recover the sum `a+b+c` exactly from `A₂`. -/
theorem recover_edgeSum (B : Box) :
    4 * Real.pi * weylA2 B = B.edgeSum := by
  unfold weylA2
  field_simp [ne_of_gt Real.pi_pos]

end PaperLean
