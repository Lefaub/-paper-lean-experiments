#!/usr/bin/env bash
set -euo pipefail
mkdir -p upstream
if [ -d upstream/cone-operator-lab/.git ]; then
  git -C upstream/cone-operator-lab pull --ff-only
else
  git clone https://github.com/Sultanow/cone-operator-lab.git upstream/cone-operator-lab
fi
