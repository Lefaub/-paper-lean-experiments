#!/usr/bin/env python3
"""Compare a numeric spectrum artifact with the exact rectangular-box formula.

The parser accepts numbers separated by whitespace, commas, semicolons, or
other text, making it usable with simple Mathematica/Python exports.
"""
from __future__ import annotations

import argparse
import math
import re
from pathlib import Path

FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")


def read_numbers(path: Path) -> list[float]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    return [float(x) for x in FLOAT_RE.findall(text)]


def exact_reference(count: int, max_observed: float, a: float, b: float, c: float) -> list[float]:
    # Any component of an eigenvalue is <= the complete eigenvalue, so these
    # bounds are sufficient to enumerate all modes below max_observed.
    cutoff = max_observed + 1e-8
    root = math.sqrt(cutoff) / math.pi
    lmax = max(1, math.ceil(a * root) + 1)
    nmax = max(1, math.ceil(b * root) + 1)
    mmax = max(1, math.ceil(c * root) + 1)

    vals: list[float] = []
    for l in range(1, lmax + 1):
        for n in range(1, nmax + 1):
            for m in range(1, mmax + 1):
                lam = math.pi**2 * ((l / a) ** 2 + (n / b) ** 2 + (m / c) ** 2)
                if lam <= cutoff + 1.0:  # generous guard around rounded artifacts
                    vals.append(lam)
    vals.sort()
    if len(vals) < count:
        raise RuntimeError(f"Reference enumeration produced only {len(vals)} values for {count} observations")
    return vals[:count]


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("path", type=Path, help="text/CSV-like file containing eigenvalues")
    p.add_argument("--a", type=float, default=1.0)
    p.add_argument("--b", type=float, default=1.5)
    p.add_argument("--c", type=float, default=2.3)
    p.add_argument("--tol", type=float, default=2e-6, help="absolute tolerance")
    args = p.parse_args()

    observed = read_numbers(args.path)
    if not observed:
        raise SystemExit("No numeric values found.")

    reference = exact_reference(len(observed), max(observed), args.a, args.b, args.c)
    diffs = [abs(x - y) for x, y in zip(observed, reference)]
    worst = max(diffs)
    bad = [(i + 1, observed[i], reference[i], diffs[i]) for i in range(len(observed)) if diffs[i] > args.tol]

    print(f"checked: {len(observed)} eigenvalues")
    print(f"box:     a={args.a}, b={args.b}, c={args.c}")
    print(f"max |Δ|: {worst:.3e}")
    if bad:
        print(f"FAIL: {len(bad)} values exceed tolerance {args.tol:g}")
        for i, obs, ref, diff in bad[:10]:
            print(f"  #{i}: observed={obs:.12g} reference={ref:.12g} |Δ|={diff:.3e}")
        return 1
    print(f"PASS: all values within tolerance {args.tol:g}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
