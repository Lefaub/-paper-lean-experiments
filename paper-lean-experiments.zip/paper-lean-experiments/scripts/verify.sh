#!/usr/bin/env bash
set -euo pipefail

lake build
python3 scripts/check_exported_spectrum.py data/paper_reference_first15.txt --tol 2e-6

echo "Core Lean build and reference-spectrum check passed."
