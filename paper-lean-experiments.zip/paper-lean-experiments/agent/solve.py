#!/usr/bin/env python3
"""Tiny local Lean proof-agent loop backed by Ollama.

It asks a local model for a replacement of the single `by\n  sorry` proof in
Experiments/AgentTarget.lean, checks the candidate with Lean, and feeds compiler
errors back to the model. A successful candidate is written to
Experiments/AgentSolved.lean; the original target is left untouched.

The Lean kernel, not the model, is the verifier.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TARGET = ROOT / "Experiments" / "AgentTarget.lean"
PLACEHOLDER = "by\n  sorry"


def ask_ollama(model: str, prompt: str) -> str:
    payload = {
        "model": model,
        "stream": False,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are a Lean 4 + mathlib proof assistant. "
                    "Return only a Lean proof beginning with `by`. "
                    "No Markdown fences, no prose, and do not restate the theorem."
                ),
            },
            {"role": "user", "content": prompt},
        ],
    }
    req = urllib.request.Request(
        "http://127.0.0.1:11434/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=600) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as exc:
        raise RuntimeError(
            "Cannot reach Ollama on http://127.0.0.1:11434. "
            "Start Ollama and pull a model first."
        ) from exc
    return data["message"]["content"].strip()


def clean_proof(text: str) -> str:
    text = text.strip()
    fenced = re.search(r"```(?:lean)?\s*(.*?)```", text, flags=re.S | re.I)
    if fenced:
        text = fenced.group(1).strip()
    matches = list(re.finditer(r"(?m)^by(?:\s|$)", text))
    if matches:
        text = text[matches[-1].start():]
    if not text.startswith("by"):
        raise ValueError("Model response does not contain a Lean proof beginning with `by`.")
    return text


def check_candidate(source: str, candidate_path: Path) -> tuple[bool, str]:
    candidate_path.write_text(source, encoding="utf-8")
    proc = subprocess.run(
        ["lake", "env", "lean", str(candidate_path.relative_to(ROOT))],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    return proc.returncode == 0, proc.stdout


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--target", type=Path, default=DEFAULT_TARGET)
    p.add_argument("--model", default=os.environ.get("OLLAMA_MODEL", "qwen3:8b"))
    p.add_argument("--attempts", type=int, default=4)
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    target = args.target if args.target.is_absolute() else ROOT / args.target
    original = target.read_text(encoding="utf-8")
    if original.count(PLACEHOLDER) != 1:
        raise SystemExit(f"Expected exactly one placeholder {PLACEHOLDER!r} in {target}")

    feedback = "No previous attempt."
    candidate_path = ROOT / "Experiments" / "AgentCandidate.lean"
    solved_path = ROOT / "Experiments" / "AgentSolved.lean"

    for attempt in range(1, args.attempts + 1):
        prompt = f"""Solve the theorem containing the placeholder in this Lean file.
Replace only:
{PLACEHOLDER}
with a complete proof starting with `by`.

Lean file:
---
{original}
---

Compiler feedback from the previous attempt:
---
{feedback[-6000:]}
---

Useful tactics may include simp, field_simp, ring, ring_nf, norm_num, positivity, rw, and exact.
Return only the replacement proof.
"""
        if args.dry_run:
            print(prompt)
            return 0

        print(f"Attempt {attempt}/{args.attempts} with {args.model}...")
        try:
            proof = clean_proof(ask_ollama(args.model, prompt))
        except Exception as exc:
            print(f"Agent error: {exc}", file=sys.stderr)
            return 2

        candidate = original.replace(PLACEHOLDER, proof)
        ok, output = check_candidate(candidate, candidate_path)
        if ok:
            solved_path.write_text(candidate, encoding="utf-8")
            candidate_path.unlink(missing_ok=True)
            print(f"Verified by Lean. Wrote {solved_path.relative_to(ROOT)}")
            return 0

        feedback = output
        print("Lean rejected the candidate; feeding diagnostics back to the model.")
        if output.strip():
            print(output[-1500:])

    print("No verified proof found within the attempt limit.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
