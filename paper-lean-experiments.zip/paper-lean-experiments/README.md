# Paper Lean Experiments

A small Lean 4 + mathlib playground for experimenting with formal verification on the mathematics and artifacts behind **Hearing the Edges: Recovering a 3D Rectangular Box from Dirichlet Eigenvalues**.

This repository is intentionally **not part of the paper**. It treats the already existing paper and replication artifacts as test material for Lean.

## What is formalized

The trusted core currently contains:

- the rectangular box and its geometric invariants;
- the exact separated Dirichlet eigenvalue formula;
- axis/mode permutation symmetry;
- exact values for the paper's working box `(1, 1.5, 2.3)`;
- the first three box Weyl coefficients;
- exact recovery of volume, surface area, and `a+b+c` from those coefficients;
- the algebraic cubic whose roots are the side lengths;
- a direct theorem linking the Weyl coefficients to that reconstruction cubic.

`Experiments/` is deliberately outside the trusted core and can contain `sorry` while we explore new statements.

## Requirements

- Git
- `elan` / Lean 4
- macOS, Linux, or Windows
- optional: VS Code + Lean 4 extension
- optional agent: Ollama

The project pins Lean **v4.33.0** and mathlib **v4.33.0**.

## Start on macOS / Linux

```bash
curl https://elan.lean-lang.org/elan-init.sh -sSf | sh
source "$HOME/.elan/env"

lake update
lake exe cache get
lake build
```

Or:

```bash
make setup
make build
```

## Verify the paper example

```bash
make verify
```

This builds the Lean core and checks the 15 eigenvalues printed in the paper against

`λ_lnm = π² ((l/a)² + (n/b)² + (m/c)²)`

for `(a,b,c)=(1,1.5,2.3)`.

You can point the same checker at an exported Mathematica/Python spectrum:

```bash
python3 scripts/check_exported_spectrum.py /path/to/eigenvalues.txt
```

The parser tolerates whitespace, comma, and general text-style numeric exports.

## Pull the original artifacts

```bash
make upstream
```

This clones <https://github.com/Sultanow/cone-operator-lab> below `upstream/` without committing a second copy into this repository.

## Optional local proof agent

An agent is useful here as an **experiment**, not as a source of trust. The model proposes a Lean proof; Lean compiles it; compiler errors are fed back into the next attempt. Only a proof accepted by Lean is emitted as solved.

On a 16 GB Apple Silicon Mac, a small starting point is Qwen3 8B:

```bash
ollama pull qwen3:8b
python3 agent/solve.py
```

or:

```bash
make agent
```

The default target is `Experiments/AgentTarget.lean`. A successful proof is written to `Experiments/AgentSolved.lean`; the original file remains unchanged.

Use another installed model with:

```bash
python3 agent/solve.py --model YOUR_MODEL --attempts 6
```

The agent uses only Python's standard library and Ollama's local HTTP endpoint.

## Repository layout

```text
PaperLeanExperiments.lean
PaperLeanExperiments/
  Geometry.lean
  Spectrum.lean
  Weyl.lean
  Reconstruction.lean
  PaperExample.lean
Experiments/
  AgentTarget.lean
  OpenProblems.lean
agent/
  solve.py
scripts/
  check_exported_spectrum.py
  fetch_upstream.sh
  verify.sh
data/
  paper_reference_first15.txt
SOURCE_MAP.md
```

## Trust boundary

The important distinction is:

```text
LLM / numerical artifact
        ↓ proposes / produces
Lean statement or candidate proof
        ↓
Lean + mathlib
        ↓
Lean kernel accepts or rejects
```

For numerical results, this repository currently checks consistency against exact reference formulas; floating-point computations themselves are not thereby converted into formal real-number proofs.

## Next useful experiments

1. formalize strict positivity of positive-index Dirichlet modes;
2. prove the `1/s²` scaling law (already staged as the agent target);
3. formalize the heat-trace factorization for the box;
4. connect heat coefficients to `A0`, `A1`, `A2`;
5. add a bridge that consumes Weyl coefficients exported by the notebook and verifies the reconstructed invariants;
6. investigate how much of the stability-boundary algebra from Appendix B can be formalized in mathlib.
