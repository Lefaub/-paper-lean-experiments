# Source map: paper → formal experiment

The repository is an **independent Lean experiment** over the mathematics and artifacts of:

> *Hearing the Edges: Recovering a 3D Rectangular Box from Dirichlet Eigenvalues*, Axioms 2026, 15(4), 284.

Paper: <https://doi.org/10.3390/axioms15040284>

Upstream artifacts: <https://github.com/Sultanow/cone-operator-lab>

## Mapping

| Paper concept | Lean / script |
|---|---|
| Box domain Ω(a,b,c) | `PaperLeanExperiments/Geometry.lean` |
| Exact Dirichlet spectrum, Eq. (2) | `PaperLeanExperiments/Spectrum.lean` |
| Working box a=1, b=1.5, c=2.3 | `paperBox` in `Geometry.lean` |
| Volume, surface area, edge invariant | `Geometry.lean` |
| Weyl coefficients A0, A1, A2 | `PaperLeanExperiments/Weyl.lean` |
| Cubic reconstruction from symmetric invariants | `PaperLeanExperiments/Reconstruction.lean` |
| First published numerical eigenvalues | `data/paper_reference_first15.txt` |
| Numeric artifact cross-check | `scripts/check_exported_spectrum.py` |
| Exploratory proof automation | `Experiments/AgentTarget.lean`, `agent/solve.py` |

## Upstream artifact hooks

The paper points to, among others:

- `mathematica/Hearing_Box_GenerateEigenvalues.nb`
- `mathematica/Hearing_Box_AnalyzeStabilitätsminimum.nb`
- `python/notebooks/Hearing_Box_ReconstructWeylCoeffs_HeatEquation_CalcStabilitätsminimumA2-2D.ipynb`
- `renderings/box_a1.0_b1.5_c2.3.blend`

Run `make upstream` to clone the upstream artifact repository into `upstream/cone-operator-lab/` (ignored by Git).

The first bridge implemented here checks exported eigenvalue lists against the exact spectral formula. More bridges can be added for fitted Weyl coefficients and reconstructed side lengths.
