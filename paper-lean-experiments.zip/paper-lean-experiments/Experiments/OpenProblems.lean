import PaperLeanExperiments

namespace PaperLean

/-!
# Open experiments

Put statements here before deciding whether they belong in the trusted core.
This file is not imported by `PaperLeanExperiments.lean`.

Suggested next targets:
* prove strict positivity for positive side lengths and positive mode indices;
* formalize monotonicity under enlarging one side length;
* connect heat-trace coefficients to the Weyl coefficients;
* formalize uniqueness of positive roots of the reconstruction cubic up to permutation;
* import/check selected numerical artifacts against exact reference statements.
-/

end PaperLean
