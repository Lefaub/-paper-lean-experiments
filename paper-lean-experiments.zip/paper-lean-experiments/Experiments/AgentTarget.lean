import PaperLeanExperiments.Spectrum

namespace PaperLean

/--
Agent playground: uniform scaling by `s` should scale normalized eigenvalues
by `1/s²`. The hypothesis `s ≠ 0` reflects the geometric interpretation.

This file is deliberately NOT imported by the main library, so the repository
build remains strict even while this theorem contains `sorry`.
-/
theorem agent_target_scale_normalized
    (B : Box) (s : ℝ) (l n m : ℕ) (hs : s ≠ 0) :
    normalizedEigenvalue (Box.scale s B) l n m =
      normalizedEigenvalue B l n m / s^2 := by
  sorry

end PaperLean
